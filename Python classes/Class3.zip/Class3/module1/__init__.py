from module1 import userDetails
from module1 import adminDetails